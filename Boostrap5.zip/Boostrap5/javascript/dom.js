console.log("Nunca niegues que te amo");

var items = document.getElementsByClassName("item");

var cantidad = items.length;

console.log(cantidad);

//-----------------------------------------

console.log("cantiadd de listas " + cantidad);

//-----------------------------------------

var div = document.createElement("div");
div;
div.innerText = "aprendiendo JavaScript";
var divUno = document.getElementById("cuatro");
divUno.appendChild(div);

//-----------------------------------------

var listas = document.getElementById("lista");

var hijo = document.createElement("li");
hijo.innerText = "li nuevo";
listas.appendChild(hijo);

//-----------------------------------------

var color = document.getElementById("tres").style.color = "red";
var color = document.getElementById("lista").style.color = "green";
var color = document.getElementById("cuatro").style.color = "black";

//-----------------------------------------

var div1 = document.createElement("div");
div1;
div1.innerText = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, amet ut assumenda nemo cupiditate vero eaque deserunt exercitationem numquam minus autem est vitae non iure, in quibusdam id similique molestiae.";
var divUno = document.getElementById("dos");
divUno.appendChild(div1);

var color3 = document.getElementById("dos").style.color="orange";

var listas = document.getElementById("lista2");
var hijo2 = document.createElement("li");
hijo2.innerText = "items4";
listas.appendChild(hijo2);

var hijo3 = document.createElement("li");
hijo3.innerText = "items5";
listas.appendChild(hijo3);

var hijo4 = document.createElement("li");
hijo4.innerText = "items6";
listas.appendChild(hijo4);

var color = document.getElementById("lista2").style.color = "cyan";