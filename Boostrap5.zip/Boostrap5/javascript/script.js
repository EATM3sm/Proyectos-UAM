console.log("NUNCA NIEGUES QUE TE AMO");
    var a = 10;
    var b = 5;
    var r = a+b;
    var m = a*b;
    var z =Math.sqrt(1249)
    var E =Math.trunc(z)
console.log("Resultado de la suma es : " + r);
console.log("Resultado de la multiplicacion es : " + m);
console.log("Resultado de la raiz cudrada es : " + z);
console.log("Resultado de la raiz sin decimal es : " + E);

var c = 500000;
var j = 2;
var numerosPrimos = [];

for (; j < c; j++) {

  if (primo(j)) {
    numerosPrimos.push(j);
  }
  
}

console.log(numerosPrimos);

function primo(numero) {

  for (var i = 2; i < numero; i++) {

    if (numero % i === 0) {
      return false;
    }

  }

  return numero !== 1;
}